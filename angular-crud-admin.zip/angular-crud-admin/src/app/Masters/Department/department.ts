
import { Component, computed, signal } from "@angular/core";
import { FormsModule } from "@angular/forms";

export interface department {
  id: number;
  name: string;   
  status: "Active" | "Inactive";
  joined: string;
}

@Component({
  selector: 'app-department',
  imports: [FormsModule],
  templateUrl: './department.html',
  styleUrls: ['./department.css'],
})

export class Department {
 departmentData = signal<department[]>([
    {
      id: 1001,
      name: "John Smith",      
      status: "Active",
      joined: "11 Aug 2026",
    },
    {
      id: 1002,
      name: "Sarah Miller",
      status: "Active",
      joined: "09 Aug 2026",
    },
    {
      id: 1003,
      name: "Ravi Kumar",
      status: "Inactive",
      joined: "06 Aug 2026",
    },
    {
      id: 1004,
      name: "James Doe",        
      status: "Active",
      joined: "03 Aug 2026",
    },
    {
      id: 1005,
      name: "Priya Shah",
      status: "Active",
      joined: "01 Aug 2026",
    },
    {
      id: 1006,
      name: "Michael Brown",
      status: "Inactive",
      joined: "28 Jul 2026",
    },
  ]);

  form: department = {id: 0,  name: "",  status: "Active", joined: "",  };
  
  query = "";
  status = "All";
  modal = signal(false);
  editingId = signal<number | null>(null);
  edit(c: department) {
    this.editingId.set(c.id);
    this.form = { ...c };
    this.modal.set(true);
  };
  
  remove(id:number) {
    if (confirm("Delete this customer?"))
      this.departmentData.update((list) => list.filter((x) => x.id !== id));
  }

  close() {this.modal.set(false);};
  save() {};
  filtered = computed(() =>
    this.departmentData().filter(
      (c) =>        
        (!this.query ||
          (c.name)
            .toLowerCase()
            .includes(this.query.toLowerCase())) &&
        (this.status === "All" || c.status === this.status),
    ),
  );
  initials(n: string) {
    return n
      .split(" ")
      .map((x) => x[0])
      .join("")
      .slice(0, 2);
  };
   openAdd() {
    this.editingId.set(null);
    this.form = {
      id: 0,
      name: "",
      status: "Active"  ,
      joined: "",     
    };
    this.modal.set(true);
  }
}

