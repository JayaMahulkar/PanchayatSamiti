import { Component, signal } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
  <div class="app-shell" [class.sidebar-open]="sidebarOpen()">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark">A</div><div><strong>Test Admin</strong><small>Nagpur</small></div></div>
      <nav>
        <a routerLink="/dashboard" routerLinkActive="active"><span>⌂</span> Dashboard</a>
        <a routerLink="/masters" routerLinkActive="active"><span>⌂</span> Masters</a>
        <!-- <a routerLink="/customers" routerLinkActive="active"><span>♙</span> Customer</a> -->
        <div class="nav-label">MANAGEMENT</div>         
        <a href="javascript:void(0)"><span>▤</span> USER</a>               
        <a href="javascript:void(0)"><span>◫</span> Reports</a>
        <div class="nav-label">SYSTEM</div>
        <a href="javascript:void(0)"><span>⚙</span> Settings</a>
      </nav>
      <div class="sidebar-footer"><div class="avatar">TM</div><div><b>Admin User</b><small>Administrator</small></div><span>⋮</span></div>
    </aside>

    <div class="main">
      <header class="topbar">
        <button class="mobile-menu" (click)="sidebarOpen.set(!sidebarOpen())">☰</button>
        <div class="search"><span>⌕</span><input placeholder="Search anything..." /></div>
        <div class="top-actions"><button class="icon-btn">☼</button><button class="icon-btn">♧<i></i></button><div class="top-avatar">TM</div></div>
      </header>
      <main class="content"><router-outlet /></main>
      <footer>AdminFlow · Free Angular CRUD Admin Theme</footer>
    </div>
  </div>`
})
export class AppComponent {
  sidebarOpen = signal(false);
}