import { Component, computed, signal } from "@angular/core";
import { FormsModule } from "@angular/forms";

interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
  status: "Active" | "Inactive";
  joined: string;
}

@Component({
  standalone: true,
  imports: [FormsModule],
  template: ` <section class="page-head">
      <div>
        <div class="eyebrow">MANAGEMENT</div>
        <h1>SUB DEpartment----------------------</h1>
        <p>Manage your customer records and account status.</p>
      </div>
      <button class="btn primary" (click)="openAdd()">+ Add Customer</button>
    </section>
    <section class="card table-card">
      <div class="toolbar">
        <div class="search-box">
          <span>⌕</span
          ><input
            [(ngModel)]="query"
            placeholder="Search by name or email..."
          />
        </div>
        <select [(ngModel)]="status">
          <option value="All">All Status</option>
          <option>Active</option>
          <option>Inactive</option></select
        ><button class="btn secondary">⇩ Export</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Customer</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Joined</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            @for (c of filtered(); track c.id) {
              <tr>
                <td>#{{ c.id }}</td>
                <td>
                  <div class="customer">
                    <div class="table-avatar">{{ initials(c.name) }}</div>
                    <b>{{ c.name }}</b>
                  </div>
                </td>
                <td>{{ c.email }}</td>
                <td>{{ c.phone }}</td>
                <td>
                  <span
                    class="badge"
                    [class.inactive]="c.status === 'Inactive'"
                    >{{ c.status }}</span
                  >
                </td>
                <td>{{ c.joined }}</td>
                <td>
                  <button class="row-action" (click)="edit(c)">✎</button
                  ><button class="row-action danger" (click)="remove(c.id)">
                    ⌫
                  </button>
                </td>
              </tr>
            } @empty {
              <tr>
                <td colspan="7" class="empty">No customers found.</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
      <div class="pagination">
        <span
          >Showing {{ filtered().length }} of
          {{ customers().length }} customers</span
        >
        <div>
          <button>‹</button><button class="current">1</button><button>2</button
          ><button>3</button><button>›</button>
        </div>
      </div>
    </section>

    @if (modal()) {
      <div class="overlay" (click)="close()">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-head">
            <div>
              <h2>{{ editingId() ? "Edit Customer" : "Add Customer" }}</h2>
              <p>Enter the customer information below.</p>
            </div>
            <button (click)="close()">×</button>
          </div>
          <form (ngSubmit)="save()">
            <div class="form-grid">
              <label
                >Full Name<input
                  [(ngModel)]="form.name"
                  name="name"
                  required
                  placeholder="e.g. John Smith" /></label
              ><label
                >Email Address<input
                  [(ngModel)]="form.email"
                  name="email"
                  type="email"
                  required
                  placeholder="john@example.com" /></label
              ><label
                >Phone Number<input
                  [(ngModel)]="form.phone"
                  name="phone"
                  required
                  placeholder="+91 98765 43210" /></label
              ><label
                >Status<select [(ngModel)]="form.status" name="status">
                  <option>Active</option>
                  <option>Inactive</option>
                </select></label
              >
            </div>
            <div class="modal-actions">
              <button type="button" class="btn secondary" (click)="close()">
                Cancel</button
              ><button class="btn primary">
                {{ editingId() ? "Save Changes" : "Create Customer" }}
              </button>
            </div>
          </form>
        </div>
      </div>
    }`,
})
export class SubDepartmentComponent {
  customers = signal<Customer[]>([
    {
      id: 1001,
      name: "John Smith",
      email: "john.smith@example.com",
      phone: "+91 98765 43210",
      status: "Active",
      joined: "11 Aug 2026",
    },
    {
      id: 1002,
      name: "Sarah Miller",
      email: "sarah.miller@example.com",
      phone: "+91 98220 11345",
      status: "Active",
      joined: "09 Aug 2026",
    },
    {
      id: 1003,
      name: "Ravi Kumar",
      email: "ravi.kumar@example.com",
      phone: "+91 97654 22110",
      status: "Inactive",
      joined: "06 Aug 2026",
    },
    {
      id: 1004,
      name: "James Doe",
      email: "james.doe@example.com",
      phone: "+91 98901 33221",
      status: "Active",
      joined: "03 Aug 2026",
    },
    {
      id: 1005,
      name: "Priya Shah",
      email: "priya.shah@example.com",
      phone: "+91 98123 44556",
      status: "Active",
      joined: "01 Aug 2026",
    },
    {
      id: 1006,
      name: "Michael Brown",
      email: "michael.b@example.com",
      phone: "+91 99220 77889",
      status: "Inactive",
      joined: "28 Jul 2026",
    },
  ]);
  query = "";
  status = "All";
  modal = signal(false);
  editingId = signal<number | null>(null);
  form: Customer = {id: 0,    name: "",    email: "",    phone: "",    status: "Active",    joined: "",  };


  filtered = computed(() =>
    this.customers().filter(
      (c) =>
        (!this.query ||
          (c.name + c.email)
            .toLowerCase()
            .includes(this.query.toLowerCase())) &&
        (this.status === "All" || c.status === this.status),
    ),
  );
  initials(n: string) {
    return n
      .split(" ")
      .map((x) => x[0])
      .join("")
      .slice(0, 2);
  }
  openAdd() {
    this.editingId.set(null);
    this.form = {
      id: 0,
      name: "",
      email: "",
      phone: "",
      status: "Active",
      joined: new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      }),
    };
    this.modal.set(true);
  }
  edit(c: Customer) {
    this.editingId.set(c.id);
    this.form = { ...c };
    this.modal.set(true);
  }
  close() {
    this.modal.set(false);
  }
  save() {
    if (!this.form.name || !this.form.email) return;
    if (this.editingId()) {
      this.customers.update((list) =>
        list.map((x) => (x.id === this.editingId() ? { ...this.form } : x)),
      );
    } else {
      this.customers.update((list) => [
        { ...this.form, id: Math.max(...list.map((x) => x.id)) + 1 },
        ...list,
      ]);
    }
    this.close();
  }
  remove(id: number) {
    if (confirm("Delete this customer?"))
      this.customers.update((list) => list.filter((x) => x.id !== id));
  }
}
