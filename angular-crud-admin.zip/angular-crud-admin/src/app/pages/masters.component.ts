import { Component } from '@angular/core';
 import { Router } from '@angular/router';

@Component({
  standalone: true,
  imports: [],
  template: `
  <section class="page-head"><div><div class="eyebrow">OVERVIEW</div><h1>MASTERS</h1><p>All Master Management</p></div></section>
  <div class="stats">
    <div (click)="RedirectToMasters('department')"><article class="stat"><div class="stat-icon purple">♙</div><div><strong>Department</strong><strong>1,248</strong><em>↑ 12.5% <span>vs last month</span></em></div></article></div>
    <div  (click)="RedirectToMasters('subdepartment')"><article class="stat"><div class="stat-icon blue">▦</div><div><strong>Sub Department</strong><strong>1,106</strong><em>↑ 8.2% <span>vs last month</span></em></div></article></div>
    <article class="stat"><div class="stat-icon green">✓</div><div><strong>Bank</strong><strong>186</strong><em>↑ 18.4% <span>vs last month</span></em></div></article>
    <!-- <article class="stat"><div class="stat-icon orange">↗</div><div><strong>TAPSHIL</strong><strong>24.8%</strong><em>↑ 3.1% <span>vs last month</span></em></div></article> -->

    <!-- <article class="stat"><div class="stat-icon purple">♙</div><div><small>Total Customers</small><strong>1,248</strong><em>↑ 12.5% <span>vs last month</span></em></div></article>
    <article class="stat"><div class="stat-icon blue">▦</div><div><small>Active Customers</small><strong>1,106</strong><em>↑ 8.2% <span>vs last month</span></em></div></article>
    <article class="stat"><div class="stat-icon green">✓</div><div><small>New This Month</small><strong>186</strong><em>↑ 18.4% <span>vs last month</span></em></div></article>
    <article class="stat"><div class="stat-icon orange">↗</div><div><small>Conversion Rate</small><strong>24.8%</strong><em>↑ 3.1% <span>vs last month</span></em></div></article>

    <article class="stat"><div class="stat-icon purple">♙</div><div><small>Total Customers</small><strong>1,248</strong><em>↑ 12.5% <span>vs last month</span></em></div></article>
    <article class="stat"><div class="stat-icon blue">▦</div><div><small>Active Customers</small><strong>1,106</strong><em>↑ 8.2% <span>vs last month</span></em></div></article>
    <article class="stat"><div class="stat-icon green">✓</div><div><small>New This Month</small><strong>186</strong><em>↑ 18.4% <span>vs last month</span></em></div></article>
    <article class="stat"><div class="stat-icon orange">↗</div><div><small>Conversion Rate</small><strong>24.8%</strong><em>↑ 3.1% <span>vs last month</span></em></div></article> -->
  </div>
  <div class="grid-two">
    <!-- <section class="card chart-card"><div class="card-head"><div><h2>Customer Growth</h2><p>Monthly customer acquisition</p></div><select><option>Last 6 months</option><option>Last year</option></select></div>
      <div class="chart"><div class="ylabels"><span>400</span><span>300</span><span>200</span><span>100</span><span>0</span></div><div class="bars"><div style="height:38%"><label>Jan</label></div><div style="height:51%"><label>Feb</label></div><div style="height:44%"><label>Mar</label></div><div style="height:67%"><label>Apr</label></div><div style="height:72%"><label>May</label></div><div style="height:88%"><label>Jun</label></div></div></div>
    </section> -->
    <!-- <section class="card"><div class="card-head"><div><h2>Recent Activity</h2><p>Latest customer updates</p></div><a routerLink="/customers">View all</a></div>
      <div class="activity"><div class="mini-avatar">JS</div><div><b>John Smith</b><span>Added a new customer</span></div><time>2m ago</time></div>
      <div class="activity"><div class="mini-avatar pink">SM</div><div><b>Sarah Miller</b><span>Updated customer profile</span></div><time>18m ago</time></div>
      <div class="activity"><div class="mini-avatar green">RK</div><div><b>Ravi Kumar</b><span>Customer status changed</span></div><time>42m ago</time></div>
      <div class="activity"><div class="mini-avatar orange">JD</div><div><b>James Doe</b><span>New customer registered</span></div><time>1h ago</time></div>
    </section> -->
  </div>`
})
export class MastersComponent {

   constructor(private router: Router) {}

  RedirectToMasters(redirectTo: string) {    
   if (redirectTo === 'department') {
        this.router.navigate(['masters/department']);
    }
    else if (redirectTo === 'subdepartment') {
        this.router.navigate(['masters/subdepartment']);
    }
  }
}