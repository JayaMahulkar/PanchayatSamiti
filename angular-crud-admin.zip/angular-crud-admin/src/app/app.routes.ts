import { Routes } from '@angular/router';
import { DashboardComponent } from './pages/dashboard.component';
import { CustomersComponent } from './pages/customers.component';
import { MastersComponent } from './pages/masters.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'masters', component: MastersComponent },
  { path: 'customers', component: CustomersComponent },
  { path: 'masters/department', 
    loadComponent: () => import('./Masters/Department/department')
    .then(m => m.Department) },
  
  
  { path: '**', redirectTo: 'dashboard' }
];