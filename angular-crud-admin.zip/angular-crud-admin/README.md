# Angular CRUD Admin

A free, modern Angular CRUD admin UI with dashboard, responsive sidebar, search, filtering, pagination, add/edit modal, delete confirmation and local in-browser data.

## Requirements

- Node.js compatible with Angular 22
- npm

Angular 22 officially supports Node.js 22.22.3+ or Node.js 24.15.0+ according to Angular's version compatibility documentation.

## Run

```bash
npm install
npm start
```

Open http://localhost:4200

## Backend integration

The customer page currently stores data in memory so it works immediately without an API. To connect ASP.NET Core Web API:

1. Create a `CustomerService` using Angular HttpClient.
2. Replace the signal mutations in `CustomersComponent` with GET/POST/PUT/DELETE calls.
3. Add `provideHttpClient()` in `main.ts`.
4. Put the API base URL in an environment configuration.

Suggested API:
- GET /api/customers
- GET /api/customers/{id}
- POST /api/customers
- PUT /api/customers/{id}
- DELETE /api/customers/{id}
